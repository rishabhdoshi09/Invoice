--
-- PostgreSQL database dump
--

\restrict qyzmpsRqawNV81EfqtXLxHRsv4Z8YyN2I67ieIhYPKfewihmYdIs5jhS3CTiI22

-- Dumped from database version 15.15 (Debian 15.15-0+deb12u1)
-- Dumped by pg_dump version 15.15 (Debian 15.15-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enum_audit_logs_action; Type: TYPE; Schema: public; Owner: Rishabh
--

CREATE TYPE public.enum_audit_logs_action AS ENUM (
    'CREATE',
    'UPDATE',
    'DELETE',
    'RESTORE',
    'LOGIN',
    'LOGOUT',
    'LOGIN_FAILED',
    'VIEW'
);


ALTER TYPE public.enum_audit_logs_action OWNER TO "Rishabh";

--
-- Name: enum_daily_expenses_paymentMode; Type: TYPE; Schema: public; Owner: Rishabh
--

CREATE TYPE public."enum_daily_expenses_paymentMode" AS ENUM (
    'cash',
    'upi',
    'bank',
    'other'
);


ALTER TYPE public."enum_daily_expenses_paymentMode" OWNER TO "Rishabh";

--
-- Name: enum_ledgers_ledgerType; Type: TYPE; Schema: public; Owner: Rishabh
--

CREATE TYPE public."enum_ledgers_ledgerType" AS ENUM (
    'asset',
    'liability',
    'income',
    'expense'
);


ALTER TYPE public."enum_ledgers_ledgerType" OWNER TO "Rishabh";

--
-- Name: enum_orderItems_type; Type: TYPE; Schema: public; Owner: Rishabh
--

CREATE TYPE public."enum_orderItems_type" AS ENUM (
    'weighted',
    'non-weighted'
);


ALTER TYPE public."enum_orderItems_type" OWNER TO "Rishabh";

--
-- Name: enum_orders_paymentStatus; Type: TYPE; Schema: public; Owner: Rishabh
--

CREATE TYPE public."enum_orders_paymentStatus" AS ENUM (
    'paid',
    'partial',
    'unpaid'
);


ALTER TYPE public."enum_orders_paymentStatus" OWNER TO "Rishabh";

--
-- Name: enum_payments_partyType; Type: TYPE; Schema: public; Owner: Rishabh
--

CREATE TYPE public."enum_payments_partyType" AS ENUM (
    'customer',
    'supplier',
    'expense'
);


ALTER TYPE public."enum_payments_partyType" OWNER TO "Rishabh";

--
-- Name: enum_payments_referenceType; Type: TYPE; Schema: public; Owner: Rishabh
--

CREATE TYPE public."enum_payments_referenceType" AS ENUM (
    'order',
    'purchase',
    'advance'
);


ALTER TYPE public."enum_payments_referenceType" OWNER TO "Rishabh";

--
-- Name: enum_products_type; Type: TYPE; Schema: public; Owner: Rishabh
--

CREATE TYPE public.enum_products_type AS ENUM (
    'weighted',
    'non-weighted'
);


ALTER TYPE public.enum_products_type OWNER TO "Rishabh";

--
-- Name: enum_purchaseBills_paymentStatus; Type: TYPE; Schema: public; Owner: Rishabh
--

CREATE TYPE public."enum_purchaseBills_paymentStatus" AS ENUM (
    'paid',
    'partial',
    'unpaid'
);


ALTER TYPE public."enum_purchaseBills_paymentStatus" OWNER TO "Rishabh";

--
-- Name: enum_purchaseItems_type; Type: TYPE; Schema: public; Owner: Rishabh
--

CREATE TYPE public."enum_purchaseItems_type" AS ENUM (
    'weighted',
    'non-weighted'
);


ALTER TYPE public."enum_purchaseItems_type" OWNER TO "Rishabh";

--
-- Name: enum_stock_transactions_type; Type: TYPE; Schema: public; Owner: Rishabh
--

CREATE TYPE public.enum_stock_transactions_type AS ENUM (
    'in',
    'out',
    'adjustment'
);


ALTER TYPE public.enum_stock_transactions_type OWNER TO "Rishabh";

--
-- Name: enum_users_role; Type: TYPE; Schema: public; Owner: Rishabh
--

CREATE TYPE public.enum_users_role AS ENUM (
    'admin',
    'billing_staff'
);


ALTER TYPE public.enum_users_role OWNER TO "Rishabh";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    "userId" uuid,
    "userName" character varying(255),
    "userRole" character varying(255),
    action public.enum_audit_logs_action NOT NULL,
    "entityType" character varying(255) NOT NULL,
    "entityId" character varying(255),
    "entityName" character varying(255),
    "oldValues" jsonb,
    "newValues" jsonb,
    description text,
    "ipAddress" character varying(255),
    "userAgent" character varying(255),
    metadata jsonb,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO "Rishabh";

--
-- Name: customers; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public.customers (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    mobile character varying(255),
    email character varying(255),
    address text,
    gstin character varying(255),
    "openingBalance" double precision,
    "currentBalance" numeric(15,2),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.customers OWNER TO "Rishabh";

--
-- Name: daily_expenses; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public.daily_expenses (
    id uuid NOT NULL,
    date date NOT NULL,
    category character varying(255) NOT NULL,
    description character varying(255),
    amount numeric(15,2) NOT NULL,
    "paidTo" character varying(255),
    "paymentMode" public."enum_daily_expenses_paymentMode" DEFAULT 'cash'::public."enum_daily_expenses_paymentMode",
    "createdBy" uuid,
    "createdByName" character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.daily_expenses OWNER TO "Rishabh";

--
-- Name: daily_summaries; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public.daily_summaries (
    id uuid NOT NULL,
    date date NOT NULL,
    "openingBalance" numeric(15,2) DEFAULT '0'::double precision,
    "openingBalanceSetAt" timestamp with time zone,
    "openingBalanceSetBy" character varying(255),
    "totalSales" numeric(15,2) DEFAULT '0'::double precision,
    "totalOrders" integer DEFAULT 0,
    "totalPurchases" numeric(15,2) DEFAULT '0'::double precision,
    "totalPaymentsReceived" numeric(15,2) DEFAULT '0'::double precision,
    "totalPaymentsMade" numeric(15,2) DEFAULT '0'::double precision,
    "lastInvoiceNumber" integer DEFAULT 0,
    "orderIds" jsonb DEFAULT '[]'::jsonb,
    "isClosed" boolean DEFAULT false,
    "closedAt" timestamp with time zone,
    "closedBy" uuid,
    "closingBalance" double precision,
    notes text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.daily_summaries OWNER TO "Rishabh";

--
-- Name: invoice_sequences; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public.invoice_sequences (
    id uuid NOT NULL,
    prefix character varying(255) DEFAULT 'INV'::character varying,
    "currentNumber" integer DEFAULT 0,
    "lastDate" date,
    "dailyNumber" integer DEFAULT 0,
    "lastFinancialYear" character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.invoice_sequences OWNER TO "Rishabh";

--
-- Name: ledgerEntries; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public."ledgerEntries" (
    id uuid NOT NULL,
    "ledgerId" uuid NOT NULL,
    "entryDate" character varying(255) NOT NULL,
    debit double precision DEFAULT '0'::double precision,
    credit double precision DEFAULT '0'::double precision,
    balance double precision DEFAULT '0'::double precision,
    description text,
    "referenceType" character varying(255),
    "referenceId" uuid,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ledgerEntries" OWNER TO "Rishabh";

--
-- Name: ledgers; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public.ledgers (
    id uuid NOT NULL,
    "ledgerName" character varying(255) NOT NULL,
    "ledgerType" public."enum_ledgers_ledgerType" NOT NULL,
    "openingBalance" double precision DEFAULT '0'::double precision,
    "currentBalance" double precision DEFAULT '0'::double precision,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.ledgers OWNER TO "Rishabh";

--
-- Name: orderItems; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public."orderItems" (
    id uuid NOT NULL,
    name text,
    "altName" text,
    quantity double precision,
    "productPrice" numeric(15,2),
    "totalPrice" numeric(15,2),
    type public."enum_orderItems_type",
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "orderId" uuid
);


ALTER TABLE public."orderItems" OWNER TO "Rishabh";

--
-- Name: orders; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public.orders (
    id uuid NOT NULL,
    "orderNumber" character varying(255),
    "orderDate" character varying(255),
    "customerName" character varying(255),
    "customerMobile" character varying(255),
    "customerGstin" character varying(255),
    "placeOfSupply" character varying(255) DEFAULT '27-Maharashtra'::character varying,
    "subTotal" numeric(15,2),
    total numeric(15,2),
    tax numeric(15,2),
    "taxPercent" double precision,
    "paidAmount" numeric(15,2) DEFAULT '0'::double precision,
    "dueAmount" numeric(15,2) DEFAULT '0'::double precision,
    "paymentStatus" public."enum_orders_paymentStatus" DEFAULT 'paid'::public."enum_orders_paymentStatus",
    "customerId" uuid,
    "createdBy" uuid,
    "createdByName" character varying(255),
    "modifiedBy" uuid,
    "modifiedByName" character varying(255),
    "isDeleted" boolean DEFAULT false,
    "deletedAt" timestamp with time zone,
    "deletedBy" uuid,
    "deletedByName" character varying(255),
    "staffNotes" text,
    "staffNotesUpdatedAt" timestamp with time zone,
    "staffNotesUpdatedBy" character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.orders OWNER TO "Rishabh";

--
-- Name: payments; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public.payments (
    id uuid NOT NULL,
    "paymentNumber" character varying(255) NOT NULL,
    "paymentDate" character varying(255) NOT NULL,
    "partyId" uuid,
    "partyName" character varying(255) NOT NULL,
    "partyType" public."enum_payments_partyType" NOT NULL,
    amount numeric(15,2) NOT NULL,
    "referenceType" public."enum_payments_referenceType" NOT NULL,
    "referenceId" uuid,
    "referenceNumber" character varying(255),
    notes text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO "Rishabh";

--
-- Name: persistence_test; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public.persistence_test (
    id integer NOT NULL,
    test_id character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    verified_at timestamp without time zone,
    test_data jsonb
);


ALTER TABLE public.persistence_test OWNER TO "Rishabh";

--
-- Name: persistence_test_id_seq; Type: SEQUENCE; Schema: public; Owner: Rishabh
--

CREATE SEQUENCE public.persistence_test_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.persistence_test_id_seq OWNER TO "Rishabh";

--
-- Name: persistence_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: Rishabh
--

ALTER SEQUENCE public.persistence_test_id_seq OWNED BY public.persistence_test.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public.products (
    id uuid NOT NULL,
    name text,
    "pricePerKg" double precision,
    type public.enum_products_type,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.products OWNER TO "Rishabh";

--
-- Name: purchaseBills; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public."purchaseBills" (
    id uuid NOT NULL,
    "billNumber" character varying(255) NOT NULL,
    "billDate" character varying(255) NOT NULL,
    "supplierId" uuid NOT NULL,
    "subTotal" numeric(15,2) DEFAULT '0'::double precision,
    tax numeric(15,2) DEFAULT '0'::double precision,
    "taxPercent" double precision DEFAULT '0'::double precision,
    total numeric(15,2) DEFAULT '0'::double precision,
    "paidAmount" numeric(15,2) DEFAULT '0'::double precision,
    "dueAmount" numeric(15,2) DEFAULT '0'::double precision,
    "paymentStatus" public."enum_purchaseBills_paymentStatus" DEFAULT 'unpaid'::public."enum_purchaseBills_paymentStatus",
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."purchaseBills" OWNER TO "Rishabh";

--
-- Name: purchaseItems; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public."purchaseItems" (
    id uuid NOT NULL,
    "purchaseBillId" uuid NOT NULL,
    name text NOT NULL,
    quantity double precision NOT NULL,
    price double precision NOT NULL,
    "totalPrice" numeric(15,2) NOT NULL,
    type public."enum_purchaseItems_type",
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."purchaseItems" OWNER TO "Rishabh";

--
-- Name: stock_transactions; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public.stock_transactions (
    id uuid NOT NULL,
    "productId" uuid NOT NULL,
    type public.enum_stock_transactions_type NOT NULL,
    quantity double precision NOT NULL,
    "previousStock" double precision DEFAULT '0'::double precision,
    "newStock" double precision DEFAULT '0'::double precision,
    "referenceType" character varying(255),
    "referenceId" uuid,
    notes text,
    "transactionDate" date NOT NULL,
    "createdBy" uuid,
    "createdByName" character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.stock_transactions OWNER TO "Rishabh";

--
-- Name: stocks; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public.stocks (
    id uuid NOT NULL,
    "productId" uuid NOT NULL,
    "currentStock" double precision DEFAULT '0'::double precision,
    "minStockLevel" double precision DEFAULT '0'::double precision,
    unit character varying(255) DEFAULT 'kg'::character varying,
    "lastUpdated" timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.stocks OWNER TO "Rishabh";

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public.suppliers (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    mobile character varying(255),
    email character varying(255),
    address text,
    gstin character varying(255),
    "openingBalance" double precision,
    "currentBalance" double precision,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.suppliers OWNER TO "Rishabh";

--
-- Name: users; Type: TABLE; Schema: public; Owner: Rishabh
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255),
    role public.enum_users_role DEFAULT 'billing_staff'::public.enum_users_role NOT NULL,
    "isActive" boolean DEFAULT true,
    "lastLogin" timestamp with time zone,
    "isDeleted" boolean DEFAULT false,
    "deletedAt" timestamp with time zone,
    "deletedBy" uuid,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.users OWNER TO "Rishabh";

--
-- Name: persistence_test id; Type: DEFAULT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.persistence_test ALTER COLUMN id SET DEFAULT nextval('public.persistence_test_id_seq'::regclass);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public.audit_logs (id, "userId", "userName", "userRole", action, "entityType", "entityId", "entityName", "oldValues", "newValues", description, "ipAddress", "userAgent", metadata, "createdAt", "updatedAt") FROM stdin;
f0c74b93-539a-47f8-940b-c2ff9d606d3d	f4698381-8e91-433f-a807-2099609272d0	admin	admin	LOGIN	AUTH	f4698381-8e91-433f-a807-2099609272d0	admin	\N	\N	LOGIN: Success	34.16.56.64	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.0 Safari/537.36	{"role": "admin"}	2026-02-08 09:02:55.967+00	2026-02-08 09:02:55.967+00
95641602-eb1a-4e79-9aa4-9f82ba871de6	f4698381-8e91-433f-a807-2099609272d0	admin	admin	LOGIN	AUTH	f4698381-8e91-433f-a807-2099609272d0	admin	\N	\N	LOGIN: Success	34.16.56.64	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.0 Safari/537.36	{"role": "admin"}	2026-02-08 09:03:18.182+00	2026-02-08 09:03:18.182+00
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public.customers (id, name, mobile, email, address, gstin, "openingBalance", "currentBalance", "createdAt", "updatedAt") FROM stdin;
fffc4df4-da2d-4151-9959-68971232865f	Test Customer	9876543210	\N	456 Customer St	\N	\N	\N	2026-02-08 09:02:34.515+00	2026-02-08 09:02:34.515+00
\.


--
-- Data for Name: daily_expenses; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public.daily_expenses (id, date, category, description, amount, "paidTo", "paymentMode", "createdBy", "createdByName", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: daily_summaries; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public.daily_summaries (id, date, "openingBalance", "openingBalanceSetAt", "openingBalanceSetBy", "totalSales", "totalOrders", "totalPurchases", "totalPaymentsReceived", "totalPaymentsMade", "lastInvoiceNumber", "orderIds", "isClosed", "closedAt", "closedBy", "closingBalance", notes, "createdAt", "updatedAt") FROM stdin;
c9d89171-8a2d-4e32-a9ba-e329686a9250	2026-02-08	0.00	\N	\N	44088659.64	10110	0.00	0.00	0.00	112	["4d4737de-5030-4229-a5b9-fb94326cf555", "4a347180-0832-458a-b8f2-ad14edc7d357", "21db90cb-1a7d-4774-ac3d-fab2b7e35611", "c3a07a19-e4c4-4a92-97b5-8b847759a9ae", "19104549-4b27-435e-9030-8986d2d77b51", "c8152126-b575-465b-8052-6ae272a7fab1", "9508a764-5063-469c-b57e-5e0009278f96", "fe6bee50-c13a-478a-9881-0cc8682a2b70", "aa1d7637-7f39-4ca3-b5a8-f81c81eed550", "25c1857e-fbb6-4151-a4e2-81ae1cc4b811", "6fb69af4-8d8d-47a9-b202-d1fc43ea3201", "9b050a13-bb44-4485-b51a-434a922cfea0", "69ea9365-f298-4939-91d1-27656be04c1d", "9b5a8b3c-56fd-4390-9fea-4bd393ad30fe", "5257b098-aadf-4bad-a876-9cb7e6fefc8b", "88395e88-afe1-43a4-9cc1-a105252b9257", "db0b4a1d-7915-45ac-b965-19fe021e07ba", "472d286d-8a92-4bbb-ac5f-5e190e2328b7", "187c2676-33bf-4f2c-8a5f-d8803f86a1e8", "ceef8f67-40ea-49ac-ac49-c9ea822d664a", "4217fd33-a7db-4c71-b53f-36180d855c91", "a84053a8-41d5-4425-b1e9-9517d93ca25d", "4972d9d9-a07a-4cb8-b49c-5df25e585424", "dd88fb37-669d-4e5f-8e0d-b069af86a087", "7a5ab707-1e98-4225-9c76-dafcda8bd5db", "f5afb129-5a34-4dd5-9aac-ecb6586b031f", "6cc56146-3fe8-450c-b276-2dfe9680c734", "59f78b26-cecb-4ca2-a977-2aed60b5d7e9", "bf51ef11-f328-4f05-9db8-2b35be53d682", "1603f1ee-d75e-4a36-ae57-c93c404d9ef7", "0f3c693f-e34e-4f33-bc65-34b97f3d9d1a", "0d02b87b-5cf3-4902-b798-15e41d7613b4", "b0d8ad1c-02f4-49d3-a3f1-a0013beed27a", "53e5efd5-bb4d-400d-a6e4-095c034bd679", "9d995e2d-98d5-4644-a6eb-56c28e0e44ab", "c3dfd5b6-0c3b-4674-938c-fc7ee9f5f3c3", "7b52339e-3684-4d18-ab16-6a962cc2e851", "83bbfe5a-27d4-433d-8b11-3a38f514eedf", "a774ce31-3d9e-4e34-8738-5e59eb5100b5", "b848d74f-4c2c-49cc-8242-3115290549d5", "c7080a71-2464-4f0b-ba9a-5169d6458b5c", "2db4baa5-1c96-4795-9b7a-77fd41c604bb", "8fdac6c7-2ba4-4b95-8a41-516c1e8fe7f7", "ee49f7a4-1ca2-490e-9cc6-93f3091be7f0", "d43c62bc-51fa-4f7a-8880-740c16e84aec", "a0b5fa72-ce43-4335-9523-330820026d12", "94731227-a00a-4bb7-a146-30fbc60ad7f9", "069f9617-84b4-453a-a9dc-ea1af833a202", "1819820b-9264-4862-ad1e-c99f1e71bce8", "a6656654-9568-48b1-a3e1-ff0d5595aa53", "f3fc3d05-35af-4ec1-900e-98c8d4e19849", "fd022be3-621b-47ae-a371-146a8cefe9f9", "7d16b4d3-b0ef-495a-a388-158dc1a41eac", "589f9008-9f80-4ec7-9c9c-c441958d75f6", "7d63c67b-4c40-4017-976e-2436cae56712", "a5f0e0b1-7573-488a-9272-7028628e409c", "c145d940-e95e-4766-8a44-46496a809d24", "ce0b8c85-378b-49c3-9d87-74fb2da9d20e", "f4b2cd9e-5007-4bd3-8b37-7d96f7f82fd0", "33031cfe-c72b-417d-baa3-8f075cafc5bf", "9ab387c6-bf75-435b-83eb-931cea7105fe", "1eef6927-5ce7-4c99-9140-ba11b75b1326", "74d21d05-dc7b-4fec-bb30-ece87b005a1f", "201e3abd-5f5a-421e-a43f-3c0ed681bd80", "d6d6a4ba-ee43-474b-a8f8-7a702f4f44c3", "3314b8d0-d0d7-4a9a-9eff-a0a0bea9bf92", "38323ba7-26b2-4916-a454-17c7d90265fb", "e197c1d9-6af0-49f1-ad59-e180854a9aa3", "5ff5eb0a-2cb5-4fa3-bee3-70c328018893", "611d6046-dacd-4709-8445-07147d5799ea", "c20e45d6-4ca3-4ae5-b4ee-adfc9bf71e3b", "417d111e-ed6b-47c9-b622-3551360f05b6", "94461235-aedd-4e7b-a7d0-53d86f39af78", "06f26784-7d3f-49c7-980d-cec3a8448458", "66ff5e92-10e4-42c7-8482-bc244e7ed8ad", "56210d1c-72c9-42fe-8b06-ae9fce35a377", "12e6af0f-d65f-484d-9732-ff85c246e907", "aa947688-4ceb-4c0c-8faf-3ca3ecf2c035", "c6ec5a52-0d9d-4220-ab06-25380e6e8102", "a784a1f4-b849-4c3c-af79-48eb2d263954", "377d4ac5-0fb8-44d4-8a77-2e8c0efc32a8", "dcc86909-fada-4071-a02c-4c65f16cc826", "3ac566c1-1de9-4fba-89c3-d54c653182ff", "22c42bc7-18e6-4fec-80a3-c8695eb2e089", "e819a59f-cefc-4af3-9f9a-091e1ce1fe54", "0bbc2887-a6bf-47fd-9e6a-d8b9f08e230b", "8f4080e4-e024-49c1-a036-996fde102531", "e577a7f4-4935-4196-9cc5-355b83ae201c", "88ea9df6-52c7-4723-bc66-cfe101ff3773", "5ed67810-5e7d-463c-9862-41f60eb29225", "a47d90eb-85dc-48d1-a962-ff6e7eab9a58", "6def982e-9b69-432c-90f6-1d87d621fff4", "8ae514cc-f845-4bc2-963e-c570696f3913", "66db394d-3f4d-49fa-b7f6-4495b1b34398", "20cd5349-016a-4e72-9570-68a8d7428a5f", "72b7348a-6d41-4234-b73d-280fed71a55b", "e2f0315a-98c0-4487-93b0-e40dab7eded4", "b6ae6888-65f8-4ae1-9025-8f78613d59a5", "7c8a71d2-602b-44d5-aaa4-4bdbb0a3360e", "697190bc-763a-41cb-a8fa-ab52db5420d1", "b041c3ec-5710-4e5c-9249-d659ff61b23d", "e84060f2-2b8b-43c6-806b-142cdec27419", "e28a0951-7c02-48b2-8397-d6967a59a8c4", "6a7564f2-6c50-492b-8021-92b95f0af15f", "84dccc09-01df-40d8-8e35-a59758b8081f", "4f8c4d90-86a6-4910-8c1b-8e749137b8f4", "69570a8c-e14e-4f68-8e36-31b409da7358", "bd0f9294-32cb-4772-836c-caaddfed6778", "297be4df-51e2-445b-b432-1761c372ffdb", "9f124169-30f4-4b18-8c96-ec8f61564f16", "7da2451c-6ecf-410a-84f0-ae8142b610be"]	f	\N	\N	\N	\N	2026-02-08 09:27:31.608+00	2026-02-08 09:27:35.867+00
\.


--
-- Data for Name: invoice_sequences; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public.invoice_sequences (id, prefix, "currentNumber", "lastDate", "dailyNumber", "lastFinancialYear", "createdAt", "updatedAt") FROM stdin;
9c0b51e8-a264-4888-8038-8c51e4970685	INV	1672	2026-02-08	1522	2025-26	2026-02-08 09:02:34.522+00	2026-02-08 09:27:33.039+00
\.


--
-- Data for Name: ledgerEntries; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public."ledgerEntries" (id, "ledgerId", "entryDate", debit, credit, balance, description, "referenceType", "referenceId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ledgers; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public.ledgers (id, "ledgerName", "ledgerType", "openingBalance", "currentBalance", "createdAt", "updatedAt") FROM stdin;
696558cd-23b0-4a05-9e80-395a7a0eed9c	Sales Account	income	0	0	2026-02-08 09:02:42.138856+00	2026-02-08 09:02:42.138856+00
3864ef4b-ff0c-4621-a388-6a3d9b7e51e1	Cash Account	asset	0	0	2026-02-08 09:02:42.138856+00	2026-02-08 09:02:42.138856+00
9bc11812-0afc-49b7-becf-b8cac0c0447f	Purchase Account	expense	0	0	2026-02-08 09:02:42.138856+00	2026-02-08 09:02:42.138856+00
\.


--
-- Data for Name: orderItems; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public."orderItems" (id, name, "altName", quantity, "productPrice", "totalPrice", type, "createdAt", "updatedAt", "orderId") FROM stdin;
31a17dbb-d438-4e17-812c-47a7184ee901	Steel Utensil A	\N	1.5	150.00	225.00	weighted	2026-02-08 09:02:34.532+00	2026-02-08 09:02:34.532+00	1ba3bbe1-a8a0-4aa6-959c-f8ab60ab0460
10606d5a-adfc-43d8-83cf-c7dae447cb6b	Steel Utensil B	\N	1.5	220.00	330.00	weighted	2026-02-08 09:02:34.54+00	2026-02-08 09:02:34.54+00	e64713f4-52c9-4d01-a2bc-cdf301b54b52
53dacad0-04e4-4c20-a38b-f8c853611322	Steel Utensil C	\N	1.5	250.00	375.00	weighted	2026-02-08 09:02:34.545+00	2026-02-08 09:02:34.545+00	582c2bb8-8773-4bc5-a482-e703223d783c
6c26870e-60e8-4752-8587-766d03023723	Steel Utensil D	\N	1.5	310.00	465.00	weighted	2026-02-08 09:02:34.551+00	2026-02-08 09:02:34.551+00	8fb5a42a-decf-476c-9edc-aa34352bf8bc
91037c64-c81f-40ee-a34d-b31f7611d394	Steel Box	\N	1.5	180.00	270.00	weighted	2026-02-08 09:02:34.556+00	2026-02-08 09:02:34.556+00	2e1125b7-4695-4fde-b1d5-f3ba5a2636b0
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public.orders (id, "orderNumber", "orderDate", "customerName", "customerMobile", "customerGstin", "placeOfSupply", "subTotal", total, tax, "taxPercent", "paidAmount", "dueAmount", "paymentStatus", "customerId", "createdBy", "createdByName", "modifiedBy", "modifiedByName", "isDeleted", "deletedAt", "deletedBy", "deletedByName", "staffNotes", "staffNotesUpdatedAt", "staffNotesUpdatedBy", "createdAt", "updatedAt") FROM stdin;
1ba3bbe1-a8a0-4aa6-959c-f8ab60ab0460	INV/2025-26/0001	17-01-2026	Test Customer	9876543210	\N	27-Maharashtra	225.00	236.25	11.25	\N	236.25	0.00	paid	\N	f4698381-8e91-433f-a807-2099609272d0	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2026-02-08 09:02:34.528+00	2026-02-08 09:02:34.528+00
e64713f4-52c9-4d01-a2bc-cdf301b54b52	INV/2025-26/0002	18-01-2026	Test Customer	9876543210	\N	27-Maharashtra	330.00	346.50	16.50	\N	346.50	0.00	paid	\N	f4698381-8e91-433f-a807-2099609272d0	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2026-02-08 09:02:34.538+00	2026-02-08 09:02:34.538+00
582c2bb8-8773-4bc5-a482-e703223d783c	INV/2025-26/0003	19-01-2026	Test Customer	9876543210	\N	27-Maharashtra	375.00	393.75	18.75	\N	393.75	0.00	paid	\N	f4698381-8e91-433f-a807-2099609272d0	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2026-02-08 09:02:34.542+00	2026-02-08 09:02:34.542+00
8fb5a42a-decf-476c-9edc-aa34352bf8bc	INV/2025-26/0004	17-01-2026	Test Customer	9876543210	\N	27-Maharashtra	465.00	488.25	23.25	\N	488.25	0.00	paid	\N	f4698381-8e91-433f-a807-2099609272d0	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2026-02-08 09:02:34.547+00	2026-02-08 09:02:34.547+00
2e1125b7-4695-4fde-b1d5-f3ba5a2636b0	INV/2025-26/0005	18-01-2026	Test Customer	9876543210	\N	27-Maharashtra	270.00	283.50	13.50	\N	283.50	0.00	paid	\N	f4698381-8e91-433f-a807-2099609272d0	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2026-02-08 09:02:34.554+00	2026-02-08 09:02:34.554+00
6cb1c367-bde9-4953-962c-a30dec4e5bfd	CRASH-TEST-001	08-02-2026	Crash Test Customer 1	9999900001	\N	27-Maharashtra	1000.00	1180.00	180.00	18	1180.00	0.00	paid	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2026-02-08 09:33:10.616137+00	2026-02-08 09:33:10.616137+00
2b74a5b8-617a-4590-b855-398c55a46678	CRASH-TEST-002	08-02-2026	Crash Test Customer 2	9999900002	\N	27-Maharashtra	2500.00	2950.00	450.00	18	0.00	2950.00	unpaid	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2026-02-08 09:33:10.616137+00	2026-02-08 09:33:10.616137+00
ff838f15-ce55-4a9e-b1d4-bae5ad989ed0	CRASH-TEST-003	08-02-2026	Crash Test Customer 3	9999900003	\N	27-Maharashtra	5000.00	5900.00	900.00	18	2950.00	2950.00	partial	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2026-02-08 09:33:10.616137+00	2026-02-08 09:33:10.616137+00
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public.payments (id, "paymentNumber", "paymentDate", "partyId", "partyName", "partyType", amount, "referenceType", "referenceId", "referenceNumber", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: persistence_test; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public.persistence_test (id, test_id, created_at, verified_at, test_data) FROM stdin;
1	CRASH_TEST_2026_02_08_093200	2026-02-08 09:33:00.266716	\N	{"test_type": "persistence_verification", "created_by": "financial_audit", "expected_survival": true}
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public.products (id, name, "pricePerKg", type, "createdAt", "updatedAt") FROM stdin;
f92ced91-b08c-4c52-91d0-cf2aee6fbfe8	Steel Utensil A	150	weighted	2026-02-08 09:02:34.488+00	2026-02-08 09:02:34.488+00
8f74b78b-f1bb-468d-8e50-373b76342bb9	Steel Utensil B	220	weighted	2026-02-08 09:02:34.494+00	2026-02-08 09:02:34.494+00
dd1457fc-fca0-4e09-8486-271a51a5b2c8	Steel Utensil C	250	weighted	2026-02-08 09:02:34.499+00	2026-02-08 09:02:34.499+00
b989618a-c13d-41f5-971f-a15585d18e99	Steel Utensil D	310	weighted	2026-02-08 09:02:34.504+00	2026-02-08 09:02:34.504+00
03b4a466-e895-46b9-8bae-efeb306c9924	Steel Box	180	non-weighted	2026-02-08 09:02:34.509+00	2026-02-08 09:02:34.509+00
\.


--
-- Data for Name: purchaseBills; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public."purchaseBills" (id, "billNumber", "billDate", "supplierId", "subTotal", tax, "taxPercent", total, "paidAmount", "dueAmount", "paymentStatus", "createdAt", "updatedAt") FROM stdin;
e6ea4b8c-3526-4f91-95a5-cc5283c647b2	PB/2025-26/0001	18-01-2026	794e1bd9-ddc9-4e0b-8f42-76c9a0183f5a	5000.00	900.00	18	5900.00	5900.00	0.00	paid	2026-02-08 09:02:34.562+00	2026-02-08 09:02:34.562+00
\.


--
-- Data for Name: purchaseItems; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public."purchaseItems" (id, "purchaseBillId", name, quantity, price, "totalPrice", type, "createdAt", "updatedAt") FROM stdin;
fae8d7be-4550-4290-9e80-21c6473731ec	e6ea4b8c-3526-4f91-95a5-cc5283c647b2	Steel Raw Material	10	500	5000.00	\N	2026-02-08 09:02:34.565+00	2026-02-08 09:02:34.565+00
\.


--
-- Data for Name: stock_transactions; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public.stock_transactions (id, "productId", type, quantity, "previousStock", "newStock", "referenceType", "referenceId", notes, "transactionDate", "createdBy", "createdByName", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: stocks; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public.stocks (id, "productId", "currentStock", "minStockLevel", unit, "lastUpdated", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public.suppliers (id, name, mobile, email, address, gstin, "openingBalance", "currentBalance", "createdAt", "updatedAt") FROM stdin;
794e1bd9-ddc9-4e0b-8f42-76c9a0183f5a	Test Supplier	\N	\N	123 Main St	27ABCDE1234F1ZK	\N	\N	2026-02-08 09:02:34.483+00	2026-02-08 09:02:34.483+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: Rishabh
--

COPY public.users (id, username, password, name, email, role, "isActive", "lastLogin", "isDeleted", "deletedAt", "deletedBy", "createdAt", "updatedAt") FROM stdin;
d0daec65-e416-4ae9-a82f-89aff910626d	staff	$2b$10$260ptt5lyUVKbvr.lfQC5.3bUfyj6VF5LPuiOpX4pOHr7FLNRQxA2	Billing Staff	\N	billing_staff	t	\N	f	\N	\N	2026-02-08 09:02:34.404+00	2026-02-08 09:02:34.404+00
f4698381-8e91-433f-a807-2099609272d0	admin	$2b$10$qsWj3RxmGdDEhn7CJ9B98eRXBnCzmT9JRRadBmCsEMoO6IHZykGte	Administrator	\N	admin	t	2026-02-08 09:03:18.177+00	f	\N	\N	2026-02-08 09:02:34.3+00	2026-02-08 09:03:18.177+00
\.


--
-- Name: persistence_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: Rishabh
--

SELECT pg_catalog.setval('public.persistence_test_id_seq', 1, true);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: daily_expenses daily_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.daily_expenses
    ADD CONSTRAINT daily_expenses_pkey PRIMARY KEY (id);


--
-- Name: daily_summaries daily_summaries_date_key; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.daily_summaries
    ADD CONSTRAINT daily_summaries_date_key UNIQUE (date);


--
-- Name: daily_summaries daily_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.daily_summaries
    ADD CONSTRAINT daily_summaries_pkey PRIMARY KEY (id);


--
-- Name: invoice_sequences invoice_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.invoice_sequences
    ADD CONSTRAINT invoice_sequences_pkey PRIMARY KEY (id);


--
-- Name: ledgerEntries ledgerEntries_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public."ledgerEntries"
    ADD CONSTRAINT "ledgerEntries_pkey" PRIMARY KEY (id);


--
-- Name: ledgers ledgers_ledgerName_key; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.ledgers
    ADD CONSTRAINT "ledgers_ledgerName_key" UNIQUE ("ledgerName");


--
-- Name: ledgers ledgers_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.ledgers
    ADD CONSTRAINT ledgers_pkey PRIMARY KEY (id);


--
-- Name: orderItems orderItems_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public."orderItems"
    ADD CONSTRAINT "orderItems_pkey" PRIMARY KEY (id);


--
-- Name: orders orders_orderNumber_key; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_orderNumber_key" UNIQUE ("orderNumber");


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payments payments_paymentNumber_key; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_paymentNumber_key" UNIQUE ("paymentNumber");


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: persistence_test persistence_test_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.persistence_test
    ADD CONSTRAINT persistence_test_pkey PRIMARY KEY (id);


--
-- Name: persistence_test persistence_test_test_id_key; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.persistence_test
    ADD CONSTRAINT persistence_test_test_id_key UNIQUE (test_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchaseBills purchaseBills_billNumber_key; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public."purchaseBills"
    ADD CONSTRAINT "purchaseBills_billNumber_key" UNIQUE ("billNumber");


--
-- Name: purchaseBills purchaseBills_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public."purchaseBills"
    ADD CONSTRAINT "purchaseBills_pkey" PRIMARY KEY (id);


--
-- Name: purchaseItems purchaseItems_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public."purchaseItems"
    ADD CONSTRAINT "purchaseItems_pkey" PRIMARY KEY (id);


--
-- Name: stock_transactions stock_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.stock_transactions
    ADD CONSTRAINT stock_transactions_pkey PRIMARY KEY (id);


--
-- Name: stocks stocks_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.stocks
    ADD CONSTRAINT stocks_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: audit_logs_action; Type: INDEX; Schema: public; Owner: Rishabh
--

CREATE INDEX audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: audit_logs_created_at; Type: INDEX; Schema: public; Owner: Rishabh
--

CREATE INDEX audit_logs_created_at ON public.audit_logs USING btree ("createdAt");


--
-- Name: audit_logs_entity_id; Type: INDEX; Schema: public; Owner: Rishabh
--

CREATE INDEX audit_logs_entity_id ON public.audit_logs USING btree ("entityId");


--
-- Name: audit_logs_entity_type; Type: INDEX; Schema: public; Owner: Rishabh
--

CREATE INDEX audit_logs_entity_type ON public.audit_logs USING btree ("entityType");


--
-- Name: audit_logs_user_id; Type: INDEX; Schema: public; Owner: Rishabh
--

CREATE INDEX audit_logs_user_id ON public.audit_logs USING btree ("userId");


--
-- Name: daily_expenses_category; Type: INDEX; Schema: public; Owner: Rishabh
--

CREATE INDEX daily_expenses_category ON public.daily_expenses USING btree (category);


--
-- Name: daily_expenses_date; Type: INDEX; Schema: public; Owner: Rishabh
--

CREATE INDEX daily_expenses_date ON public.daily_expenses USING btree (date);


--
-- Name: daily_summaries_date; Type: INDEX; Schema: public; Owner: Rishabh
--

CREATE UNIQUE INDEX daily_summaries_date ON public.daily_summaries USING btree (date);


--
-- Name: ledgerEntries ledgerEntries_ledgerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public."ledgerEntries"
    ADD CONSTRAINT "ledgerEntries_ledgerId_fkey" FOREIGN KEY ("ledgerId") REFERENCES public.ledgers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orderItems orderItems_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public."orderItems"
    ADD CONSTRAINT "orderItems_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchaseBills purchaseBills_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public."purchaseBills"
    ADD CONSTRAINT "purchaseBills_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public.suppliers(id) ON UPDATE CASCADE;


--
-- Name: purchaseItems purchaseItems_purchaseBillId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public."purchaseItems"
    ADD CONSTRAINT "purchaseItems_purchaseBillId_fkey" FOREIGN KEY ("purchaseBillId") REFERENCES public."purchaseBills"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_transactions stock_transactions_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.stock_transactions
    ADD CONSTRAINT "stock_transactions_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE;


--
-- Name: stocks stocks_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Rishabh
--

ALTER TABLE ONLY public.stocks
    ADD CONSTRAINT "stocks_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict qyzmpsRqawNV81EfqtXLxHRsv4Z8YyN2I67ieIhYPKfewihmYdIs5jhS3CTiI22

